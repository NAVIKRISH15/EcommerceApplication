package entity;

import java.sql.Date;
import java.util.Map.Entry;

public class Orders {
private int order_id;
private int customer_id;
private String order_date;
private double price;
private String shipping_address;

public Orders()
{
	}
Orders(int order_id,int customer_id,String order_date,double price,String shipping_address){
	this.order_id=order_id;
	this.customer_id=customer_id;
	this.order_date=order_date;
	this.price=price;
	this.shipping_address=shipping_address;
}
public int getOrder_id() {
	return order_id;
}
public void setOrder_id(int order_id) {
	this.order_id = order_id;
}
public int getCustomer_id() {
	return customer_id;
}
public void setCustomer_id(int customer_id) {
	this.customer_id = customer_id;
}
public String getOrder_date() {
	return order_date;
}
public void setOrder_date(String date) {
	this.order_date = date;
}
public double getPrice() {
	return price;
}
public void setPrice(double price) {
	this.price = price;
}
public String getShipping_address() {
	return shipping_address;
}
public void setShipping_address(String shipping_address) {
	this.shipping_address = shipping_address;
}
public String toString() {
	return "Orders[order_id="+order_id+"]";
}
public Entry<Products, Integer>[] entrySet() {
	// TODO Auto-generated method stub
	return null;
}
}

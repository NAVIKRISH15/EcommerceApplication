package testing;

import static org.junit.Assert.*;

import java.lang.reflect.Executable;

import org.junit.Test;

import entity.Customers;
import myExceptions.*;
import dao.*;
public class ExceptionTest {

	@Test
	public void test()throws CustomerNotFoundException {
        
		 final Customers customer = new Customers();
		    customer.setCustomer_id(999);
		    final OrderProcessorRepositoryImpl obj = new OrderProcessorRepositoryImpl();

		    assertThrows(CustomerNotFoundException.class, () -> {
		        obj.deleteCustomer(customer);
		    });
}}

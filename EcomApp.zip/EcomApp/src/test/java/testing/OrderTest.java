package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import entity.*;
import dao.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
class OrderTest {

	@Test
	public void testPlaceOrder() {
		
	        
	        Customers customer = new Customers();
	        customer.setCustomer_id(1); 

	        Products product = new Products();
	        product.setProduct_id(1); // Assuming this is a valid product ID

	        
	        List<Map<Products, Integer>> productsQuantityMap = new ArrayList<>();
	        Map<Products, Integer> orderItem = new HashMap<>();
	        orderItem.put(product, 1); 
	        productsQuantityMap.add(orderItem);

	       
	       final  OrderProcessorRepositoryImpl obj = new OrderProcessorRepositoryImpl();
	       boolean result=obj.placeOrder(customer, productsQuantityMap, "123 Shipping St.");
			

	        
	        assertTrue(result);
	}

}

package dao;
import java.util.List;
import java.util.Map;
import entity.*;
import myExceptions.*;

public interface OrderProcessorRepository {
	public boolean createProduct(Products product);
	public boolean createCustomer(Customers customer);
	public boolean deleteProduct(Products product) throws ProductNotFoundException;
	public boolean deleteCustomer(Customers customer) throws CustomerNotFoundException;
	public boolean addToCart(Customers customer,Products product,Cart cart);
	public boolean removeFromCart(Customers customer,Products product);
	public List<Products> getAllFromCart(Customers customer);
	public boolean placeOrder(Customers customer, List<Map<Products, Integer>> productsQuantityMap, String shippingAddress);
	//public List<Map<Products, Integer>> getOrdersByCustomer(int customerId) throws OrderNotFoundException; 
	public List<Orders> getOrdersByCustomer(int customerId) throws OrderNotFoundException;
}

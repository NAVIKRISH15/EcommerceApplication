package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;


import entity.*;
import dao.*;

	
public class ProductTest {
	
	@BeforeAll
    static void start() {
        System.out.println("connection start  ");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("connection close test");
    }
    
	    @Test
	    public void testProductCreation() {
	        
	        Products product = new Products();
	        product.setProduct_id(1); 
	        product.setProduct_name("Test Product");
	        product.setPrice(10.0);
	        product.setDescription("Moisturizer");
	        product.setStockQuantity(40);
	        
	        OrderProcessorRepositoryImpl obj = new OrderProcessorRepositoryImpl();
	        boolean result = obj.createProduct(product);
	        
	        assertTrue(result); 
	    }


}

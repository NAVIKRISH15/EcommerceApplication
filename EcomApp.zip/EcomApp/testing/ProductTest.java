package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import EcomService.*;
import entity.*;
import dao.*;

	
public class ProductTest {

	    @Test
	    public void testProductCreation() {
	        
	        Products product = new Products();
	        product.setProduct_id(1); 
	        product.setProduct_name("Test Product");
	        product.setPrice(10.0);
	        product.setDescription("Moisturizer");
	        product.setStockQuantity(40);
	        
	        OrderProcessorRepositoryImpl obj = new OrderProcessorRepositoryImpl();
	        boolean result = obj.createProduct(product);
	        
	        assertTrue(result); 
	    }


}

package dao;
import entity.*;
import util.*;
import java.sql.*;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import myExceptions.*;
public class OrderProcessorRepositoryImpl implements OrderProcessorRepository {
	public Connection con;
    PreparedStatement stat;
    
    public OrderProcessorRepositoryImpl() {
   	 this.con=DBConnection.getConnect();
    }
	public boolean createCustomer(Customers customer) {
	
	 try {
		 stat = con.prepareStatement("insert into customers values(?,?,?,?)");
		 stat.setInt(1,customer.getCustomer_id());
		 stat.setString(2, customer.getName());
		 stat.setString(3, customer.getEmail());
		 stat.setString(4, customer.getPassword());
		 int rowsaffected=stat.executeUpdate();
		 
		 if(rowsaffected>0)
			{
				return true;
			}
			else
				return false;

	 }
	 catch(Exception e) {
		 System.out.println(e.getMessage());
		 return false;
	 }
}
	
	public boolean createProduct(Products product) {
		 try {
    		 stat=con.prepareStatement("insert into products values(?,?,?,?,?)");
    		 stat.setInt(1, product.getProduct_id());
    		 stat.setString(2, product.getProduct_name());
    		 stat.setDouble(3, product.getPrice());
    		 stat.setString(4, product.getDescription());
    		 stat.setInt(5, product.getStockQuantity());
    		 int rowsaffected=stat.executeUpdate();
    		 
    		 if(rowsaffected>0)
 			{
 				return true;
 			}
 			else
 				return false;
    		 
		 
    	 }
    	catch(Exception e) {
    		System.out.println(e.getMessage());
    		return false;
    	}
	}


	public boolean deleteProduct(Products product) throws ProductNotFoundException {
	 
		 try {
    		 stat=con.prepareStatement("delete from products where product_id=?");
    		 stat.setInt(1, product.getProduct_id());
    		 int rowsaffected=stat.executeUpdate();
    		 if(rowsaffected>0)
  			{
  				return true;
  			}
  			else
  			{
  				throw new ProductNotFoundException("Product with ID " + product.getProduct_id() + " not found");
  			}
		 }
		 
    		 catch (SQLException e) {
    		     
    		        e.printStackTrace();
    		        throw new ProductNotFoundException("Error deleting product: " + e.getMessage());
    		 }
	}
	public boolean deleteCustomer(Customers customer) throws CustomerNotFoundException  {
		
		 try {
    		 stat=con.prepareStatement("delete from customers where customer_id=?");
    		 stat.setInt(1,customer.getCustomer_id());
    		 int rowsaffected=stat.executeUpdate();
    		
    		 if(rowsaffected>0)
  			{
  				return true;
  			}
    		 else {
    	            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomer_id() + " not found");
    	        }
    	    } 
		 catch (SQLException e) {
    	      
    	        e.printStackTrace();
    	        throw new CustomerNotFoundException("Error deleting customer: " + e.getMessage());
    	    }
	}

	public boolean addToCart(Customers customer,Products product,Cart cart) {
		 try {
    		 stat=con.prepareStatement("insert into cart(cart_id,customer_id, product_id, quantity) values(?,?,?,?)");
    		 stat.setInt(1, cart.getCart_id());
    		 stat.setInt(2,customer.getCustomer_id());
    		 stat.setInt(3, product.getProduct_id());
    		 stat.setInt(4,cart.getQuantity());
    		 int rowsaffected=stat.executeUpdate();
    		 if(rowsaffected>0)
  			{
  				return true;
  			}
  			else
  				return false;
     		 
    	 }
    	 catch(Exception e) {
    		 System.out.println(e.getMessage());
    		 return false;
    	 }
	}
	public boolean removeFromCart(Customers customer,Products product) {
		 try {
    		 stat=con.prepareStatement("delete from cart where customer_id=? and product_id=?");
    		 stat.setInt(1, customer.getCustomer_id());
    		 stat.setInt(2, product.getProduct_id());
    		 int rowsaffected=stat.executeUpdate();
    		 if(rowsaffected>0)
   			{
   				return true;
   			}
   			else
   				return false;
      		 
     	 
    	 }
    	 catch(Exception e) {
    		 System.out.println(e.getMessage());
    		 return false;
    	 }
	}
	public List<Products> getAllFromCart(Customers customer){
		
		try {
			
			stat=con.prepareStatement("SELECT p.* FROM products p " +
	                   "JOIN cart c ON p.product_id = c.product_id " +
	                   "WHERE c.customer_id = ?");
			stat.setInt(1, customer.getCustomer_id());
			ResultSet rs=stat.executeQuery();
			if (rs.next()) {
               
                System.out.println(rs.getInt("product_id"));
                System.out.println(rs.getString("name"));
    
            }
			else {
				System.out.println("Customer Id not found");
			}
		}
		catch (SQLException e) {
            e.printStackTrace(); 
        }
		return null;
	}
	
	public List<Orders> getOrdersByCustomer(int customerId) throws OrderNotFoundException {
        List<Orders> orderList = new ArrayList<>();
        boolean flag=false;
        try (Connection conn = DBConnection.getConnect()) {
            String query = "SELECT * FROM orders WHERE customer_id = ?";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setInt(1, customerId);
            ResultSet rs = stat.executeQuery();
            while (rs.next()) {
                Orders order = new Orders();
                order.setOrder_id(rs.getInt("order_id"));
                order.setCustomer_id(rs.getInt("customer_id"));
                order.setOrder_date(rs.getString("order_date"));
                order.setPrice(rs.getDouble("total_price"));
                order.setShipping_address(rs.getString("shipping_address"));
                orderList.add(order);
                flag=true;
            }
            if(flag==false) {
            	String customer_id = null;
				throw new OrderNotFoundException("No orders found for customer with ID: " + customer_id);
        }} catch (Exception e) {
            System.out.println(e);
        }
        return orderList;
    }
  
	public boolean placeOrder(Customers customer, List<Map<Products, Integer>> productsQuantityMap, String shippingAddress) {
	    String insertOrderQuery = "INSERT INTO orders (customer_id, order_date, total_price, shipping_address) VALUES (?, NOW(), ?, ?)";
	    String insertOrderItemQuery = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";

	    try {
	        con.setAutoCommit(false);

	        PreparedStatement orderStatement = con.prepareStatement(insertOrderQuery, Statement.RETURN_GENERATED_KEYS);
	        orderStatement.setInt(1, customer.getCustomer_id());
	        double totalPrice = calculateTotalPrice(productsQuantityMap);
	        orderStatement.setDouble(2, totalPrice);
	        orderStatement.setString(3, shippingAddress);
	        int rowsAffected = orderStatement.executeUpdate();
	        if (rowsAffected == 0) {
	            con.rollback();
	            return false;
	        }

	        ResultSet generatedKeys = orderStatement.getGeneratedKeys();
	        int orderId;
	        if (generatedKeys.next()) {
	            orderId = generatedKeys.getInt(1);
	        } else {
	            con.rollback();
	            return false;
	        }

	        // Insert into order_items table
	        PreparedStatement orderItemStatement = con.prepareStatement(insertOrderItemQuery);
	        for (Map<Products, Integer> entry : productsQuantityMap) {
	            for (Map.Entry<Products, Integer> productQuantityEntry : entry.entrySet()) {
	                Products product = productQuantityEntry.getKey();
	                int quantity = productQuantityEntry.getValue();
	                orderItemStatement.setInt(1, orderId); // Use the generated order ID
	                orderItemStatement.setInt(2, product.getProduct_id());
	                orderItemStatement.setInt(3, quantity);
	                orderItemStatement.addBatch();
	            }
	        }

	        int[] batchResult = orderItemStatement.executeBatch();
	        for (int result : batchResult) {
	            if (result <= 0) {
	                con.rollback();
	                return false;
	            }
	        }

	        con.commit();
	        return true;

	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
	}
	private double calculateTotalPrice(List<Map<Products, Integer>> productsQuantityMap) {
		
		return 0;
	}
    

	}
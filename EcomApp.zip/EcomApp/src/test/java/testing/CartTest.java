package testing;

import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;

import entity.*;
import dao.*;
public class CartTest {
	@BeforeAll
    static void start() {
        System.out.println("connection start  ");
    }

    @AfterAll
    static void cleanup() {
        System.out.println("connection close test");
    }
	 @Test
	 public void testAddToCart() {
		 
	       Cart cart=new Cart();
	       cart.setCart_id(3);
	       Customers customer = new Customers();
	        customer.setCustomer_id(32); 

	        Products product = new Products();
	        product.setProduct_id(1); 
           cart.setQuantity(1);

	        OrderProcessorRepositoryImpl obj = new OrderProcessorRepositoryImpl();
	       
	        boolean result =  obj.addToCart(customer, product, cart); 

	        
	        assertTrue(result);
}}

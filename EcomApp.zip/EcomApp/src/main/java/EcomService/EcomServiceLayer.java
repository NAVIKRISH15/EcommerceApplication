package EcomService;

import java.util.*;
import dao.*;
import myExceptions.*;
import entity.*;
public class EcomServiceLayer {
		Scanner sc;
		OrderProcessorRepositoryImpl cdao ;

		public  EcomServiceLayer(){
			sc=new Scanner(System.in);
			cdao=new OrderProcessorRepositoryImpl();
		}


		public void createCustomer() {
			Customers customer=new Customers();
			System.out.println("enter the customer Id:");
			customer.setCustomer_id(sc.nextInt());
			
			System.out.println("enter the customer name:");
			sc.nextLine();
			customer.setName(sc.nextLine());
			
			System.out.println("enter the customer email:");
			customer.setEmail(sc.nextLine());
			
			System.out.println("enter the customer password:");
			customer.setPassword(sc.nextLine());
			
			boolean result=cdao.createCustomer( customer);
			if(result) {
				System.out.println("added customer Successfully");
			}
			else {
				System.out.println("Failed to update");
			}
}
		
		public void createProduct() {
			Products product =new Products();
			System.out.println("Enter the product Id:");
			product.setProduct_id(sc.nextInt());
			
			System.out.println("Enter the product name");
			sc.nextLine();
			product.setProduct_name(sc.nextLine());
			
			System.out.println("Enter the product Price");
			product.setPrice(sc.nextDouble());
			
			System.out.println("Enter the product Description");
			sc.nextLine();
			product.setDescription(sc.nextLine());
			
			System.out.println("Enter the quantity of the product");
			product.setStockQuantity(sc.nextInt());
			
			boolean result=cdao.createProduct(product);
			if(result) {
				System.out.println("added Product Successfully");
			}
			else {
				System.out.println("Failed to update");
			}
			
		}

		public void deleteProduct() throws ProductNotFoundException {
			Products product =new Products();
			System.out.println("Enter the product Id:");
			product.setProduct_id(sc.nextInt());
			
			boolean result=cdao.deleteProduct(product);
			if(result) {
				System.out.println(" Product removed Successfully");
			}
			else {
				System.out.println("Failed to remove");
			}
			
		}
		public void deleteCustomer() throws CustomerNotFoundException {
			Customers customer=new Customers();
			System.out.println("enter the customer Id to be removed:");
			customer.setCustomer_id(sc.nextInt());
			boolean result=cdao.deleteCustomer(customer);
			if(result) {
				System.out.println("Customer removed Successfully");
			}
			else {
				System.out.println("Failed to remove");
			}
			
		}

		public void addToCart() {
			Customers customer=new Customers();
			Products product =new Products();
			Cart cart=new Cart();
			System.out.println("enter the crart id:");
			cart.setCart_id(sc.nextInt());
		    
			System.out.println("enter the customer Id:");
			customer.setCustomer_id(sc.nextInt());
			
			System.out.println("Enter the product Id:");
			product.setProduct_id(sc.nextInt());
			
			System.out.println("enter the quantity");
			cart.setQuantity(sc.nextInt());
			boolean result=cdao.addToCart(customer,product,cart);
			if(result) {
				System.out.println("Added to cart");
			}
			else {
				System.out.println("Failed to add");
			}
			
		}

public void removeFromCart() {
	Customers customer=new Customers();
	Products product =new Products();
	System.out.println("enter the customer Id:");
	customer.setCustomer_id(sc.nextInt());
	
	System.out.println("Enter the product Id:");
	product.setProduct_id(sc.nextInt());
	boolean result=cdao.removeFromCart(customer,product);
	if(result) {
		System.out.println("Removed from cart");
	}
	else {
		System.out.println("Failed to remove");
	}
}
public List<Products> getAllFromCart() {
    List<Products> products = new ArrayList<Products>();
    Customers customer = new Customers();
    System.out.println("Enter customer Id:");
    customer.setCustomer_id(sc.nextInt());
    products = cdao.getAllFromCart(customer);
    return products;

}

public List<Orders> getOrdersByCustomer() throws OrderNotFoundException {
 
    Customers customer = new Customers();
    System.out.println("Enter customer Id:");
    customer.setCustomer_id(sc.nextInt());
    List<Orders> p = cdao.getOrdersByCustomer(customer.getCustomer_id());
    return p;
}


public void placeOrder() {
    Customers customer = new Customers();
    List<Map<Products, Integer>> productsQuantityMap = new ArrayList<Map<Products, Integer>>();
    String shippingAddress;

    System.out.println("Enter customer ID:");
    customer.setCustomer_id(sc.nextInt());

   
    System.out.println("Enter shipping address:");
    sc.nextLine();
    shippingAddress = sc.nextLine();

    boolean result = cdao.placeOrder(customer, productsQuantityMap, shippingAddress);
    if (result) {
        System.out.println("Order placed successfully.");
    } else {
        System.out.println("Failed to place order.");
    }
}}
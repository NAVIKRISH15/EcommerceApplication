package main;
import EcomService.*;
import myExceptions.*;
import java.util.*;

public class EcomApp {
	public static void main(String args[]) {
		EcomServiceLayer obj=new EcomServiceLayer();
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("1.Register Customer");
		System.out.println("2.Create Product");
		System.out.println("3.Remove Product");
		System.out.println("4.Remove Customer");
		System.out.println("5.Add to cart");
		System.out.println("6.Remove from Cart");
		System.out.println("7.List the product in cart for a customer");
		System.out.println("8.Place Order");
		System.out.println("9.Get orders by customer Id");
		System.out.println("10.exit");
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
       switch(ch) {
       case 1:
    	   obj.createCustomer();
    	   break;
       case 2:
    	   obj.createProduct();
    	   break;
       case 3:
    	   try {
    	   obj.deleteProduct();
    	   }
    	   catch( ProductNotFoundException e) {
    		   System.out.println(e.getMessage());
    	   }
    	   break;
       case 4:
    	   try {
    	   obj.deleteCustomer();
    	   }
    	   catch(CustomerNotFoundException e) {
    		   System.out.println(e.getMessage());
    	   }
    	   break;
       case 5:
    	   obj.addToCart();
    	   break;
		
       case 6:
    	   obj.removeFromCart();
           break;
       case 7:
    	   obj.getAllFromCart();
		   break;
       case 8:
    	   obj.placeOrder();
    	   
    	   break;
       case 9:
    	   try {
    	   obj.getOrdersByCustomer();
    	   }
    	   catch( OrderNotFoundException e) {
    		   System.out.println(e.getMessage());
    	   }
       case 10:
    	    System.exit(0);
			break;
       default:
    	   break;
		
	}
       
		}

}
}